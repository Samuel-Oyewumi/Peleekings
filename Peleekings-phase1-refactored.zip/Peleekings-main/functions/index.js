const admin = require("firebase-admin");
const functions = require("firebase-functions");

admin.initializeApp();
const db = admin.firestore();

function normalizeInitial(value) {
  return String(value || "").trim().charAt(0).toUpperCase() || "X";
}

function corperBase(profile) {
  const surnameInitial = normalizeInitial(profile.surname || profile.fullName?.split(" ")[0]);
  const firstNameInitial = normalizeInitial(profile.firstName || profile.fullName?.split(" ")[1]);
  const digits = String(profile.nyscStateCode || "").replace(/\D/g, "");
  const numericSegment = digits.slice(-4).padStart(4, "0");
  return `${surnameInitial}${firstNameInitial}${numericSegment}`;
}

function nonCorperBase(profile) {
  const surnameInitial = normalizeInitial(profile.surname || profile.fullName?.split(" ")[0]);
  const firstNameInitial = normalizeInitial(profile.firstName || profile.fullName?.split(" ")[1]);
  const random = Math.floor(1000 + Math.random() * 9000);
  return `${random}${firstNameInitial}${surnameInitial}`;
}

async function claimUniqueRegistrationNumber(profile) {
  const userRef = db.collection("users").doc(profile.uid);
  const isCorper = profile.studentType === "corper";
  const base = isCorper ? corperBase(profile) : nonCorperBase(profile);

  for (let attempt = 0; attempt < 10; attempt += 1) {
    const candidate = isCorper
      ? (attempt === 0 ? base : `${base}${String.fromCharCode(64 + attempt)}`)
      : (attempt === 0 ? base : nonCorperBase(profile));
    const reservationRef = db.collection("registrationNumbers").doc(candidate);

    try {
      await db.runTransaction(async (transaction) => {
        const [reservation, user] = await Promise.all([
          transaction.get(reservationRef),
          transaction.get(userRef),
        ]);

        if (reservation.exists) throw new Error("REGISTRATION_NUMBER_TAKEN");
        if (!user.exists) throw new Error("USER_PROFILE_NOT_FOUND");
        if (user.data().regNumber) return;

        transaction.create(reservationRef, {
          uid: profile.uid,
          createdAt: admin.firestore.FieldValue.serverTimestamp(),
        });
        transaction.update(userRef, {
          regNumber: candidate,
          updatedAt: admin.firestore.FieldValue.serverTimestamp(),
        });
      });

      return candidate;
    } catch (error) {
      if (error.message === "USER_PROFILE_NOT_FOUND") return null;
      if (error.message !== "REGISTRATION_NUMBER_TAKEN") throw error;
    }
  }

  throw new Error(`Could not allocate a unique registration number for ${profile.uid}`);
}

// The Auth trigger runs after account creation. The frontend creates the basic
// profile immediately after signup; this trigger retries briefly if that write
// has not landed yet, then allocates a unique registration number.
exports.assignRegistrationNumber = functions.auth.user().onCreate(async (user) => {
  const userRef = db.collection("users").doc(user.uid);

  for (let attempt = 0; attempt < 5; attempt += 1) {
    const snapshot = await userRef.get();
    if (snapshot.exists) {
      const profile = { uid: user.uid, ...snapshot.data() };
      if (profile.regNumber) return null;
      await claimUniqueRegistrationNumber(profile);
      return null;
    }
    await new Promise((resolve) => setTimeout(resolve, 500 * (attempt + 1)));
  }

  console.error(`Profile for ${user.uid} was not created in time for registration assignment.`);
  return null;
});
