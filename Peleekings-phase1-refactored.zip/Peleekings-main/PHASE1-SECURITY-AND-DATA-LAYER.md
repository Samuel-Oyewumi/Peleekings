# Peleekings Phase 1 — Security & Data Layer Refactor

## Completed

- Firebase Auth is now the only authentication authority. Removed localStorage/sessionStorage auth state.
- Removed email-based admin authorization from the frontend.
- Client-created profiles are restricted to the safe `student` role; privileged role changes remain backend-only.
- Added a Cloud Function for unique registration-number assignment using Firestore reservation documents.
- Registration number generation moved out of the browser.
- Replaced learner enrollment/progress persistence in localStorage with Firestore `enrollments/{uid}_{courseId}`.
- Replaced fake assignment submissions with Firebase Storage upload + Firestore submission records.
- Restricted assignment files to an explicit supported file-type allowlist.
- Restricted portrait uploads to image types only.
- Added tutor ownership checks to course, module and submission access rules.
- Added private user notification rules.
- Removed fake PDF/TXT course-resource downloads and fake certificate generation from the learner UI.
- Moved the static course catalog out of page components to remove the Home <-> activity service dependency.
- Fixed the favicon path from `/vite.svg` to `/favicon.svg`.
- Added `.env.example` and moved Firebase configuration to Vite environment variables.
- Simplified routing to a single React Router tree.

## Important deployment steps

1. Copy `.env.example` to `.env.local` and provide the Firebase web configuration.
2. Install root dependencies with `npm ci`.
3. Install Functions dependencies with `cd functions && npm ci`.
4. Deploy rules and the registration function:
   `firebase deploy --only firestore:rules,storage,functions`
5. Ensure the intended admin account has `role: "admin"` in its Firestore user document. Do not assign admin from the browser.

## Not yet complete

- Dynamic Firestore course/module catalog.
- Full tutor approval transaction and custom-claim synchronization.
- Real test engine and `testSubmissions` UI.
- Real course resource records and download URLs.
- Real certificates and certificate verification endpoint.
- Firestore announcements/notifications UI.
- Real platform analytics.
- Automated unit/integration/E2E tests.
- Production monitoring and App Check.
