import { createContext, useContext, useEffect, useState } from "react";
import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut,
  onAuthStateChanged,
  updateProfile,
  GoogleAuthProvider,
  signInWithPopup,
  sendPasswordResetEmail,
} from "firebase/auth";
import { doc, getDoc, setDoc, serverTimestamp } from "firebase/firestore";
import { auth, db } from "../firebase";

const AuthContext = createContext(null);

function formatAuthError(err) {
  if (!err) return "An unknown authentication error occurred.";
  const code = err.code || "";
  switch (code) {
    case "auth/invalid-credential":
    case "auth/wrong-password":
    case "auth/user-not-found":
      return "Invalid email or password. Please verify your credentials.";
    case "auth/email-already-in-use":
      return "An account with this email address already exists. Please sign in.";
    case "auth/weak-password":
      return "Password should be at least 6 characters.";
    case "auth/invalid-email":
      return "Please enter a valid email address.";
    case "auth/network-request-failed":
      return "Network connection issue. Please check your internet connection.";
    case "auth/too-many-requests":
      return "Too many unsuccessful attempts. Please try again later or reset your password.";
    case "auth/popup-closed-by-user":
      return "Google sign-in was cancelled before completion.";
    default:
      return err.message || "Authentication failed. Please try again.";
  }
}

function buildProfile(user, fields = {}) {
  const displayName = (fields.fullName || fields.displayName || user.displayName || user.email?.split("@")[0] || "Learner").trim();

  return {
    uid: user.uid,
    email: user.email || "",
    displayName,
    fullName: displayName,
    surname: fields.surname || "",
    firstName: fields.firstName || displayName.split(" ")[0] || "",
    otherName: fields.otherName || null,
    studentType: fields.studentType || "non_corper",
    nyscStateCode: fields.studentType === "corper" ? (fields.nyscStateCode || null) : null,
    phoneNumber: fields.phoneNumber || "",
    role: "student",
    regNumber: null,
    portraitUrl: null,
    status: "active",
    createdAt: fields.createdAt || serverTimestamp(),
  };
}

async function readUserProfile(uid) {
  const snapshot = await getDoc(doc(db, "users", uid));
  return snapshot.exists() ? snapshot.data() : null;
}

async function waitForRegistrationNumber(uid, timeoutMs = 5000) {
  const startedAt = Date.now();
  while (Date.now() - startedAt < timeoutMs) {
    const profile = await readUserProfile(uid);
    if (profile?.regNumber) return profile;
    await new Promise((resolve) => setTimeout(resolve, 500));
  }
  return readUserProfile(uid);
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) throw new Error("useAuth must be used within an AuthProvider");
  return context;
}

export function AuthProvider({ children }) {
  const [currentUser, setCurrentUser] = useState(null);
  const [userProfile, setUserProfile] = useState(null);
  const [loading, setLoading] = useState(true);

  async function ensureProfile(user, fields = {}) {
    const existing = await readUserProfile(user.uid);
    if (existing) return existing;

    const profile = buildProfile(user, fields);
    await setDoc(doc(db, "users", user.uid), profile);
    return profile;
  }

  async function hydrateUser(user, fields = {}) {
    if (!user) {
      setCurrentUser(null);
      setUserProfile(null);
      return null;
    }

    const profile = await ensureProfile(user, fields);
    const userObj = {
      uid: user.uid,
      email: user.email,
      displayName: profile?.fullName || user.displayName || user.email?.split("@")[0] || "Learner",
      photoURL: user.photoURL || null,
    };

    setCurrentUser(userObj);
    setUserProfile(profile);
    return { user: userObj, role: profile?.role || "student", profile };
  }

  async function signup(email, password, displayName, customProfile = {}) {
    const cleanEmail = (email || "").trim().toLowerCase();
    const cleanName = (displayName || "").trim();

    if (!cleanEmail) throw new Error("Please provide a valid email address.");
    if (!password || password.length < 6) throw new Error("Password must be at least 6 characters.");
    if (!cleanName) throw new Error("Please provide your full name.");

    try {
      const userCredential = await createUserWithEmailAndPassword(auth, cleanEmail, password);
      const user = userCredential.user;

      if (cleanName) {
        await updateProfile(user, { displayName: cleanName });
      }

      // The client may create a basic profile, but cannot assign role, registration
      // number, enrollments or other privileged fields. Those belong to backend flows.
      let profile = await ensureProfile(user, {
        ...customProfile,
        fullName: cleanName,
        displayName: cleanName,
      });

      // Registration numbers are issued by the backend trigger. Give the UI a
      // short window to display the real value, without making signup dependent
      // on the trigger being immediately available.
      profile = await waitForRegistrationNumber(user.uid) || profile;

      return {
        user: {
          uid: user.uid,
          email: user.email,
          displayName: cleanName,
          photoURL: user.photoURL || null,
        },
        role: profile?.role || "student",
        profile,
      };
    } catch (err) {
      throw new Error(formatAuthError(err));
    }
  }

  async function login(email, password) {
    const cleanEmail = (email || "").trim().toLowerCase();
    if (!cleanEmail) throw new Error("Please enter your email address.");
    if (!password) throw new Error("Please enter your password.");

    try {
      const userCredential = await signInWithEmailAndPassword(auth, cleanEmail, password);
      return await hydrateUser(userCredential.user);
    } catch (err) {
      throw new Error(formatAuthError(err));
    }
  }

  async function loginWithGoogle() {
    try {
      const provider = new GoogleAuthProvider();
      const result = await signInWithPopup(auth, provider);
      return await hydrateUser(result.user, {
        fullName: result.user.displayName || "",
      });
    } catch (err) {
      throw new Error(formatAuthError(err));
    }
  }

  function resetPassword(email) {
    const cleanEmail = (email || "").trim().toLowerCase();
    if (!cleanEmail) throw new Error("Please enter your email address to reset password.");
    return sendPasswordResetEmail(auth, cleanEmail);
  }

  async function logout() {
    await signOut(auth);
    setCurrentUser(null);
    setUserProfile(null);
  }

  // Roles are security-sensitive and must not be changed by a client-side call.
  // This function remains exported for backwards compatibility with existing UI.
  async function updateUserRole() {
    throw new Error("Role changes must be performed through the secured admin backend.");
  }

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      setLoading(true);
      try {
        if (!user) {
          setCurrentUser(null);
          setUserProfile(null);
          return;
        }

        const profile = await readUserProfile(user.uid);
        const userObj = {
          uid: user.uid,
          email: user.email,
          displayName: profile?.fullName || user.displayName || user.email?.split("@")[0] || "Learner",
          photoURL: user.photoURL || null,
        };
        setCurrentUser(userObj);
        setUserProfile(profile);
      } catch (err) {
        console.error("Unable to load authenticated user profile:", err);
        setCurrentUser(null);
        setUserProfile(null);
      } finally {
        setLoading(false);
      }
    });

    return unsubscribe;
  }, []);

  const value = {
    currentUser,
    userProfile,
    loading,
    signup,
    login,
    logout,
    loginWithGoogle,
    resetPassword,
    updateUserRole,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}
