// Firestore-backed learner activity service.
// Authentication is handled by Firebase Auth; this module owns learner enrollment,
// progress and assignment persistence. localStorage is intentionally not used for
// authoritative learning state.

import {
  collection,
  doc,
  getDoc,
  getDocs,
  query,
  where,
  setDoc,
  serverTimestamp,
} from "firebase/firestore";
import { getDownloadURL, ref, uploadBytes } from "firebase/storage";
import { db, storage } from "../firebase";
import { COURSES_CATALOG } from "../data/courses";

const emptyActivity = {
  enrolledCourses: [],
  completedLessons: {},
  weeklyActivity: null,
  milestones: [],
  assignmentSubmissions: {},
};

function courseSnapshot(course) {
  return {
    id: course.id,
    title: course.title,
    type: "Online",
    progress: 0,
    currentModule: "Module 1",
    image: course.image,
  };
}

export async function getUserActivity(userId) {
  if (!userId) return emptyActivity;

  const [enrollmentSnapshot, submissionSnapshot] = await Promise.all([
    getDocs(query(collection(db, "enrollments"), where("uid", "==", userId))),
    getDocs(query(collection(db, "assignmentSubmissions"), where("uid", "==", userId))),
  ]);

  const completedLessons = {};
  const enrolledCourses = enrollmentSnapshot.docs.map((item) => {
    const data = item.data();
    completedLessons[data.courseId] = data.completedItemIds || data.completedLessonIds || [];
    const catalog = COURSES_CATALOG.find((course) => course.id === data.courseId);
    const total = Math.max(data.totalLessons || 1, 1);
    const progress = Math.round(((data.completedItemIds || data.completedLessonIds || []).length / total) * 100);

    return {
      ...(catalog ? courseSnapshot(catalog) : { id: data.courseId, title: data.courseTitle || "Course", image: "" }),
      type: data.experienceType === "hands-on" ? "Hands-on" : "Online",
      progress,
      currentModule: data.currentModule || "Module 1",
      enrolledAt: data.enrolledAt,
    };
  });

  const assignmentSubmissions = {};
  submissionSnapshot.docs.forEach((item) => {
    const data = item.data();
    assignmentSubmissions[data.assignmentId] = { id: item.id, ...data };
  });

  return {
    ...emptyActivity,
    enrolledCourses,
    completedLessons,
    assignmentSubmissions,
  };
}

export async function enrollInCourse(userId, courseId, experienceType = "online", totalLessons = 1) {
  if (!userId) throw new Error("You must be signed in to enroll in a course.");

  const course = COURSES_CATALOG.find((item) => item.id === courseId);
  if (!course) throw new Error("This course could not be found.");

  const enrollmentId = `${userId}_${courseId}`;
  const enrollmentRef = doc(db, "enrollments", enrollmentId);
  const existing = await getDoc(enrollmentRef);

  if (!existing.exists()) {
    await setDoc(enrollmentRef, {
      uid: userId,
      courseId,
      courseTitle: course.title,
      experienceType,
      completedItemIds: [],
      progressPercent: 0,
      totalLessons: Math.max(totalLessons, 1),
      currentModule: "Module 1",
      enrolledAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
  }

  return getUserActivity(userId);
}

export async function toggleLessonCompletion(userId, courseId, lessonId, totalCourseLessons = 1) {
  if (!userId) throw new Error("You must be signed in to update progress.");

  const enrollmentRef = doc(db, "enrollments", `${userId}_${courseId}`);
  const snapshot = await getDoc(enrollmentRef);
  if (!snapshot.exists()) throw new Error("Enroll in this course before tracking lesson progress.");

  const data = snapshot.data();
  const completed = new Set(data.completedItemIds || data.completedLessonIds || []);

  if (completed.has(lessonId)) completed.delete(lessonId);
  else completed.add(lessonId);

  const completedLessonIds = Array.from(completed);
  const progress = Math.min(100, Math.round((completedLessonIds.length / Math.max(totalCourseLessons, 1)) * 100));

  await setDoc(enrollmentRef, {
    completedItemIds: completedLessonIds,
    progressPercent: progress,
    totalLessons: Math.max(totalCourseLessons, 1),
    currentModule: `Module ${Math.max(1, Math.ceil((completedLessonIds.length / Math.max(totalCourseLessons, 1)) * 10))}`,
    updatedAt: serverTimestamp(),
  }, { merge: true });

  return getUserActivity(userId);
}

export async function submitAssignment(userId, assignment, submissionData) {
  if (!userId) throw new Error("You must be signed in to submit an assignment.");
  if (!assignment?.id) throw new Error("Assignment information is missing.");

  const submissionId = `${userId}_${assignment.id}`;
  let fileUrl = null;
  let filePath = null;

  if (submissionData.file) {
    const safeName = submissionData.file.name.replace(/[^a-zA-Z0-9._-]/g, "_");
    filePath = `courses/${assignment.courseId || "general"}/submissions/${userId}/${submissionId}-${safeName}`;
    const storageRef = ref(storage, filePath);
    const uploadResult = await uploadBytes(storageRef, submissionData.file, {
      contentType: submissionData.file.type || "application/octet-stream",
    });
    fileUrl = await getDownloadURL(uploadResult.ref);
  }

  const submission = {
    uid: userId,
    assignmentId: assignment.id,
    courseId: assignment.courseId || null,
    courseTitle: assignment.course || null,
    fileName: submissionData.file?.name || null,
    fileSize: submissionData.file?.size || null,
    fileType: submissionData.file?.type || null,
    fileUrl,
    filePath,
    projectLink: submissionData.projectLink || null,
    notes: submissionData.notes || null,
    status: "submitted",
    submittedAt: serverTimestamp(),
  };

  await setDoc(doc(db, "assignmentSubmissions", submissionId), submission, { merge: true });
  return getUserActivity(userId);
}

export function saveUserActivity() {
  throw new Error("Direct local activity writes are no longer supported. Use a Firestore service operation.");
}

export async function submitUserMilestone() {
  throw new Error("Milestones are not yet available in the production data layer.");
}
